To learn more about the font family and its license, visit https://www.fontmirror.com/subtle-curves

License: Free for personal use.
This is a preview font for testing, you can purchase its full version at https://www.creativefabrica.com/product/subtle-curves/ref/1095569/.You can donate to the font author via PayPal at dadiomouse@gmail.com